package com.example.administrator.mcs_bc;

import java.net.Socket;
import java.util.ArrayList;

class ClassforRunning_t
{

	
	//Communication entity list and potential list
	public ArrayList<String> OutgoingList;
	public ArrayList<String> IncomingList;
	public ArrayList<Socket> OutgoingSocket;
	public ArrayList<Socket> IncomingSocket;
	
	//
	
}







