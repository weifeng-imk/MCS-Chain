package com.example.administrator.mcs_bc;


class location
{
	int block_no;
	int type;
	int location;
}

