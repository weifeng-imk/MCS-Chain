package com.example.administrator.mcs_bc;
class Record_t
{
	int type;
	int block_no;
	int index;
}