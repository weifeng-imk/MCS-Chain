package com.example.administrator.mcs_bc;
//import java.io.DataInputStream;
//import java.io.IOException;
//import java.net.Socket;
//import java.net.SocketTimeoutException;
//
//import it.unisa.dia.gas.jpbc.Element;
//
//public class Test1
//{
//	public static void main(String args[]) throws Exception
//	{
//		BasicCrypto bc = new BasicCrypto();
//		bc.hashCode();
//		
//
//		
//		
//		Node_t node = new Node_t();
//		System.out.println(node.state_listening);
//		while(true)
//		{
//		
			
//		}
//		
//		
//		 
//		 
//	// System.out.println("The end");
//	}
//}
