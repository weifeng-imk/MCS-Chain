package com.example.administrator.mcs_bc;
/*
Lable: 0-> none; 1 -> task; 2 -> bid; 3-> data



*/